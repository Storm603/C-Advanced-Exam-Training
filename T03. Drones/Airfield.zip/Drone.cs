﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Drones
{
    public class Drone
    {
        public string Name;
        public string Brand;
        public int Range;
        public bool Available;

        public Drone(string name, string brand, int range)
        {
            Name = name;
            Brand = brand;
            Range = range;
            Available = true;
        }

        public override string ToString()
        {
            return $"Drone: {Name}\nManufactured by: {Brand}\nRange: {Range} kilometers";
        }
    }
}
