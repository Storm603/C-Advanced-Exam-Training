﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Guild
{
    public class Guild
    {
        public List<Player> roster;
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => roster.Count;
        public Guild(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            roster = new List<Player>();
        }

        public void AddPlayer(Player player)
        {
            if (roster.Count < Capacity)
            {
                roster.Add(player);
            }
        }

        public bool RemovePlayer(string name)
        {
            Player player = roster.FirstOrDefault(x => x.Name == name);
            return roster.Remove(player);
        }

        public void PromotePlayer(string name)
        {
            Player player = roster.FirstOrDefault(x => x.Name == name && x.Rank == "Trial");
            if (player != null)
            {
                player.Rank = "Member";
            }

            //foreach (Player player in roster)
            //{
            //    if (player.Name == name && player.Rank == "Trial")
            //    {
            //        player.Rank = "Member";
            //        break;
            //    }
            //}
        }

        public void DemotePlayer(string name)
        {
            Player player = roster.FirstOrDefault(x => x.Name == name && x.Rank == "Member");
            if (player != null)
            {
                player.Rank = "Trial";
            }

            //foreach (Player player in roster)
            //{
            //    if (player.Name == name && player.Rank == "Member")
            //    {
            //        player.Rank = "Trial";
            //        break;
            //    }
            //}
        }

        public Player[] KickPlayersByClass(string clas)
        {
            List<Player> collection = new List<Player>();

            for (int i = roster.Count - 1; i >= 0; i--)
            {
                if (roster[i].Class == clas)
                {
                    collection.Add(roster[i]);
                    roster.RemoveAt(i);
                }
            }

            Player[] arr = collection.ToArray();
            return arr.Reverse().ToArray();
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Players in the guild: {Name}");

            roster.ForEach(x => sb.AppendLine(x.ToString()));
            
            return sb.ToString().Trim();
        }
    }
}
