﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guild
{
    public class Player
    {
        public string Name { get; set; }
        public string Class { get; set; }
        public string Rank { get; set; }
        public string Description { get; set; }

        //public Player(string name, string clas, string rank, string description) : this(name, clas, rank)
        //{
        //    Description = description;
        //}
        //public Player(string name, string clas, string rank) : this(name, clas)
        //{

        //    Rank = rank;
        //}
        public Player(string name, string clas)
        {
            Name = name;
            Class = clas;
            Rank = "Trial";
            Description = "n/a";
        }

        public override string ToString()
        {
            return $"Player {Name}: {Class}\nRank: {Rank}\nDescription: {Description}";
        }
    }
}
